package com.example.assignment;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SummaryActivity extends AppCompatActivity {

    private TextView dateTextView, caloriesTakenTextView, caloriesNeededTextView,
            remainingCaloriesTextView, workoutsSummaryTextView;
    private CircularProgressIndicator progressChart;
    private ImageButton backButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        // Initialize views
        backButton = findViewById(R.id.backButton);
        dateTextView = findViewById(R.id.dateTextView);
        caloriesTakenTextView = findViewById(R.id.caloriesTakenTextView);
        caloriesNeededTextView = findViewById(R.id.caloriesNeededTextView);
        remainingCaloriesTextView = findViewById(R.id.remainingCaloriesTextView);
        workoutsSummaryTextView = findViewById(R.id.workoutsSummaryTextView);
        progressChart = findViewById(R.id.progressChart);

        dbHelper = new DatabaseHelper(this);

        // Set current date
        String currentDate = new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(new Date());
        dateTextView.setText(currentDate);

        // Set back button click listener
        backButton.setOnClickListener(v -> finish());

        // Load user data
        loadUserData();
    }

    private void loadUserData() {
        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String userEmail = prefs.getString("user_email", "");

        if (userEmail != null && !userEmail.isEmpty()) {
            // Get today's calories data
            double[] caloriesData = dbHelper.getTodayCaloriesData(userEmail);
            double caloriesTaken = caloriesData[0];
            double caloriesNeeded = caloriesData[1];
            double remainingCalories = Math.max(0, caloriesNeeded - caloriesTaken);

            // Update UI
            caloriesTakenTextView.setText(String.format(Locale.getDefault(), "%.0f kcal", caloriesTaken));
            caloriesNeededTextView.setText(String.format(Locale.getDefault(), "%.0f kcal", caloriesNeeded));
            remainingCaloriesTextView.setText(String.format(Locale.getDefault(), "%.0f kcal", remainingCalories));

            // Calculate and set progress
            int progress = (int) ((caloriesTaken / caloriesNeeded) * 100);
            progressChart.setProgress(progress);

            // Change progress color based on percentage
            if (progress >= 100) {
                progressChart.setIndicatorColor(getResources().getColor(R.color.red));
            } else if (progress >= 75) {
                progressChart.setIndicatorColor(getResources().getColor(R.color.orange));
            } else {
                progressChart.setIndicatorColor(getResources().getColor(R.color.green));
            }

            // Load workout summary
            loadWorkoutSummary(userEmail);
        }
    }

    private void loadWorkoutSummary(String userEmail) {
        // Get today's date
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Check each workout table for today's entries
        StringBuilder workoutSummary = new StringBuilder();

        // Check abs workouts
        Cursor absCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_ABS_WORKOUTS);
        if (absCursor != null && absCursor.getCount() > 0) {
            workoutSummary.append("• Abs Workout\n");
            absCursor.close();
        }

        // Check arm workouts
        Cursor armCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_ARM_WORKOUTS);
        if (armCursor != null && armCursor.getCount() > 0) {
            workoutSummary.append("• Arm Workout\n");
            armCursor.close();
        }

        // Check back workouts
        Cursor backCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_BACK_WORKOUTS);
        if (backCursor != null && backCursor.getCount() > 0) {
            workoutSummary.append("• Back Workout\n");
            backCursor.close();
        }

        // Check cardio workouts
        Cursor cardioCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_CARDIO_WORKOUTS);
        if (cardioCursor != null && cardioCursor.getCount() > 0) {
            workoutSummary.append("• Cardio Workout\n");
            cardioCursor.close();
        }

        // Check chest workouts
        Cursor chestCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_CHEST_WORKOUTS);
        if (chestCursor != null && chestCursor.getCount() > 0) {
            workoutSummary.append("• Chest Workout\n");
            chestCursor.close();
        }

        // Check leg workouts
        Cursor legCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_LEG_WORKOUTS);
        if (legCursor != null && legCursor.getCount() > 0) {
            workoutSummary.append("• Leg Workout\n");
            legCursor.close();
        }

        // Check shoulder workouts
        Cursor shoulderCursor = dbHelper.getTodayWorkouts(userEmail, DatabaseHelper.TABLE_SHOULDER_WORKOUTS);
        if (shoulderCursor != null && shoulderCursor.getCount() > 0) {
            workoutSummary.append("• Shoulder Workout\n");
            shoulderCursor.close();
        }

        if (workoutSummary.length() > 0) {
            workoutsSummaryTextView.setText(workoutSummary.toString());
        } else {
            workoutsSummaryTextView.setText("No workouts recorded today");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to activity
        loadUserData();
    }
}