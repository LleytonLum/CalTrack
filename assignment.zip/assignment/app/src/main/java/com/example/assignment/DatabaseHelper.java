package com.example.assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Users.db";
    private static final int DATABASE_VERSION = 9; // Incremented version to add workout tables

    // Table and column names
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PASSWORD = "password";

    // Profile table and columns
    public static final String TABLE_PROFILES = "profiles";
    public static final String COLUMN_USER_EMAIL = "user_email";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_HEIGHT = "height";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_WEIGHT_GOAL = "weight_goal";

    // Calories table and columns
    public static final String TABLE_CALORIES = "calories";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_CALORIES_TAKEN = "calories_taken";
    public static final String COLUMN_CALORIES_NEEDED = "calories_needed";

    // Workout tables
    public static final String TABLE_ABS_WORKOUTS = "abs_workouts";
    public static final String TABLE_ARM_WORKOUTS = "arm_workouts";
    public static final String TABLE_BACK_WORKOUTS = "back_workouts";
    public static final String TABLE_CARDIO_WORKOUTS = "cardio_workouts";
    public static final String TABLE_CHEST_WORKOUTS = "chest_workouts";
    public static final String TABLE_LEG_WORKOUTS = "leg_workouts";
    public static final String TABLE_SHOULDER_WORKOUTS = "shoulder_workouts";

    // Common workout columns
    public static final String COLUMN_WORKOUT_DATE = "workout_date";
    public static final String COLUMN_WORKOUT_NOTES = "notes";

    // Create table SQL queries
    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_EMAIL + " TEXT UNIQUE,"
                    + COLUMN_PASSWORD + " TEXT"
                    + ")";

    private static final String CREATE_TABLE_PROFILES =
            "CREATE TABLE " + TABLE_PROFILES + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT UNIQUE,"
                    + COLUMN_AGE + " INTEGER,"
                    + COLUMN_WEIGHT + " REAL,"
                    + COLUMN_HEIGHT + " REAL,"
                    + COLUMN_GENDER + " TEXT,"
                    + COLUMN_WEIGHT_GOAL + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    private static final String CREATE_TABLE_CALORIES =
            "CREATE TABLE " + TABLE_CALORIES + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_DATE + " TEXT,"
                    + COLUMN_CALORIES_TAKEN + " REAL,"
                    + COLUMN_CALORIES_NEEDED + " REAL,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + "),"
                    + "UNIQUE(" + COLUMN_USER_EMAIL + ", " + COLUMN_DATE + ")"
                    + ")";

    // Abs workouts table
    private static final String CREATE_TABLE_ABS_WORKOUTS =
            "CREATE TABLE " + TABLE_ABS_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "crunches_sets INTEGER,"
                    + "crunches_reps INTEGER,"
                    + "leg_raises_sets INTEGER,"
                    + "leg_raises_reps INTEGER,"
                    + "plank_duration INTEGER,"
                    + "plank_sets INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Arm workouts table
    private static final String CREATE_TABLE_ARM_WORKOUTS =
            "CREATE TABLE " + TABLE_ARM_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "bicep_curl_weight REAL,"
                    + "bicep_curl_sets INTEGER,"
                    + "bicep_curl_reps INTEGER,"
                    + "tricep_dips_weight TEXT,"
                    + "tricep_dips_sets INTEGER,"
                    + "tricep_dips_reps INTEGER,"
                    + "hammer_curl_weight REAL,"
                    + "hammer_curl_sets INTEGER,"
                    + "hammer_curl_reps INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Back workouts table
    private static final String CREATE_TABLE_BACK_WORKOUTS =
            "CREATE TABLE " + TABLE_BACK_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "lat_pulldown_weight REAL,"
                    + "lat_pulldown_sets INTEGER,"
                    + "lat_pulldown_reps INTEGER,"
                    + "deadlift_weight REAL,"
                    + "deadlift_sets INTEGER,"
                    + "deadlift_reps INTEGER,"
                    + "seated_row_weight REAL,"
                    + "seated_row_sets INTEGER,"
                    + "seated_row_reps INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Cardio workouts table
    private static final String CREATE_TABLE_CARDIO_WORKOUTS =
            "CREATE TABLE " + TABLE_CARDIO_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "running_duration INTEGER,"
                    + "jump_rope_duration INTEGER,"
                    + "cycling_duration INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Chest workouts table
    private static final String CREATE_TABLE_CHEST_WORKOUTS =
            "CREATE TABLE " + TABLE_CHEST_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "bench_press_weight REAL,"
                    + "bench_press_sets INTEGER,"
                    + "bench_press_reps INTEGER,"
                    + "chest_fly_weight REAL,"
                    + "chest_fly_sets INTEGER,"
                    + "chest_fly_reps INTEGER,"
                    + "push_up_weight TEXT,"
                    + "push_up_sets INTEGER,"
                    + "push_up_reps INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Leg workouts table
    private static final String CREATE_TABLE_LEG_WORKOUTS =
            "CREATE TABLE " + TABLE_LEG_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "squats_weight REAL,"
                    + "squats_sets INTEGER,"
                    + "squats_reps INTEGER,"
                    + "leg_press_weight REAL,"
                    + "leg_press_sets INTEGER,"
                    + "leg_press_reps INTEGER,"
                    + "lunges_weight REAL,"
                    + "lunges_sets INTEGER,"
                    + "lunges_reps INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    // Shoulder workouts table
    private static final String CREATE_TABLE_SHOULDER_WORKOUTS =
            "CREATE TABLE " + TABLE_SHOULDER_WORKOUTS + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USER_EMAIL + " TEXT,"
                    + COLUMN_WORKOUT_DATE + " TEXT,"
                    + "overhead_press_weight REAL,"
                    + "overhead_press_sets INTEGER,"
                    + "overhead_press_reps INTEGER,"
                    + "lateral_raise_weight REAL,"
                    + "lateral_raise_sets INTEGER,"
                    + "lateral_raise_reps INTEGER,"
                    + "front_raise_weight REAL,"
                    + "front_raise_sets INTEGER,"
                    + "front_raise_reps INTEGER,"
                    + COLUMN_WORKOUT_NOTES + " TEXT,"
                    + "FOREIGN KEY(" + COLUMN_USER_EMAIL + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_EMAIL + ")"
                    + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_PROFILES);
        db.execSQL(CREATE_TABLE_CALORIES);
        db.execSQL(CREATE_TABLE_ABS_WORKOUTS);
        db.execSQL(CREATE_TABLE_ARM_WORKOUTS);
        db.execSQL(CREATE_TABLE_BACK_WORKOUTS);
        db.execSQL(CREATE_TABLE_CARDIO_WORKOUTS);
        db.execSQL(CREATE_TABLE_CHEST_WORKOUTS);
        db.execSQL(CREATE_TABLE_LEG_WORKOUTS);
        db.execSQL(CREATE_TABLE_SHOULDER_WORKOUTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE " + TABLE_PROFILES + " ADD COLUMN " +
                    COLUMN_WEIGHT_GOAL + " TEXT");
        } else if (oldVersion < 5) {
            db.execSQL(CREATE_TABLE_CALORIES);
        } else if (oldVersion < 9) {
            // Add all the workout tables
            db.execSQL(CREATE_TABLE_ABS_WORKOUTS);
            db.execSQL(CREATE_TABLE_ARM_WORKOUTS);
            db.execSQL(CREATE_TABLE_BACK_WORKOUTS);
            db.execSQL(CREATE_TABLE_CARDIO_WORKOUTS);
            db.execSQL(CREATE_TABLE_CHEST_WORKOUTS);
            db.execSQL(CREATE_TABLE_LEG_WORKOUTS);
            db.execSQL(CREATE_TABLE_SHOULDER_WORKOUTS);
        } else {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CALORIES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_ABS_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_ARM_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_BACK_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CARDIO_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHEST_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_LEG_WORKOUTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOULDER_WORKOUTS);
            onCreate(db);
        }
    }

    public long addUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }

    public User getUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_EMAIL, COLUMN_PASSWORD},
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))
            );
            cursor.close();
            return user;
        }
        return null;
    }

    public boolean saveProfile(String email, int age, float weight, float height,
                               String gender, String weightGoal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_AGE, age);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_GENDER, gender);
        values.put(COLUMN_WEIGHT_GOAL, weightGoal);

        Cursor cursor = db.query(TABLE_PROFILES,
                new String[]{COLUMN_ID},
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            int rowsAffected = db.update(TABLE_PROFILES, values,
                    COLUMN_USER_EMAIL + " = ?", new String[]{email});
            cursor.close();
            return rowsAffected > 0;
        } else {
            long id = db.insert(TABLE_PROFILES, null, values);
            return id != -1;
        }
    }

    public Profile getProfile(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROFILES,
                new String[]{COLUMN_AGE, COLUMN_WEIGHT, COLUMN_HEIGHT,
                        COLUMN_GENDER, COLUMN_WEIGHT_GOAL},
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Profile profile = new Profile(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AGE)),
                    cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT)),
                    cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_HEIGHT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GENDER)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_GOAL))
            );
            cursor.close();
            return profile;
        }
        return null;
    }

    public double calculateCaloriesNeeded(String email) {
        Profile profile = getProfile(email);
        if (profile == null) return 0;

        double bmr;
        if (profile.getGender().equalsIgnoreCase("male")) {
            bmr = (10 * profile.getWeight()) + (6.25 * profile.getHeight()) - (5 * profile.getAge()) + 5;
        } else {
            bmr = (10 * profile.getWeight()) + (6.25 * profile.getHeight()) - (5 * profile.getAge()) - 161;
        }

        // Apply moderate activity multiplier (1.55)
        return bmr * 1.55;
    }

    public boolean saveCaloriesData(String email, double caloriesTaken) {
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        double caloriesNeeded = calculateCaloriesNeeded(email);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_DATE, currentDate);
        values.put(COLUMN_CALORIES_TAKEN, caloriesTaken);
        values.put(COLUMN_CALORIES_NEEDED, caloriesNeeded);

        Cursor cursor = db.query(TABLE_CALORIES,
                new String[]{COLUMN_ID},
                COLUMN_USER_EMAIL + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{email, currentDate},
                null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            int rowsAffected = db.update(TABLE_CALORIES, values,
                    COLUMN_USER_EMAIL + " = ? AND " + COLUMN_DATE + " = ?",
                    new String[]{email, currentDate});
            cursor.close();
            return rowsAffected > 0;
        } else {
            long id = db.insert(TABLE_CALORIES, null, values);
            return id != -1;
        }
    }

    public double[] getTodayCaloriesData(String email) {
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CALORIES,
                new String[]{COLUMN_CALORIES_TAKEN, COLUMN_CALORIES_NEEDED},
                COLUMN_USER_EMAIL + " = ? AND " + COLUMN_DATE + " = ?",
                new String[]{email, currentDate},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            double[] data = new double[]{
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CALORIES_TAKEN)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CALORIES_NEEDED))
            };
            cursor.close();
            return data;
        }
        return new double[]{0, calculateCaloriesNeeded(email)};
    }

    // Workout saving methods
    public long saveAbsWorkout(String email, int crunchesSets, int crunchesReps,
                               int legRaisesSets, int legRaisesReps,
                               int plankDuration, int plankSets, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("crunches_sets", crunchesSets);
        values.put("crunches_reps", crunchesReps);
        values.put("leg_raises_sets", legRaisesSets);
        values.put("leg_raises_reps", legRaisesReps);
        values.put("plank_duration", plankDuration);
        values.put("plank_sets", plankSets);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_ABS_WORKOUTS, null, values);
    }

    public long saveArmWorkout(String email, double bicepCurlWeight, int bicepCurlSets, int bicepCurlReps,
                               String tricepDipsWeight, int tricepDipsSets, int tricepDipsReps,
                               double hammerCurlWeight, int hammerCurlSets, int hammerCurlReps, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("bicep_curl_weight", bicepCurlWeight);
        values.put("bicep_curl_sets", bicepCurlSets);
        values.put("bicep_curl_reps", bicepCurlReps);
        values.put("tricep_dips_weight", tricepDipsWeight);
        values.put("tricep_dips_sets", tricepDipsSets);
        values.put("tricep_dips_reps", tricepDipsReps);
        values.put("hammer_curl_weight", hammerCurlWeight);
        values.put("hammer_curl_sets", hammerCurlSets);
        values.put("hammer_curl_reps", hammerCurlReps);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_ARM_WORKOUTS, null, values);
    }

    public long saveBackWorkout(String email, double latPulldownWeight, int latPulldownSets, int latPulldownReps,
                                double deadliftWeight, int deadliftSets, int deadliftReps,
                                double seatedRowWeight, int seatedRowSets, int seatedRowReps, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("lat_pulldown_weight", latPulldownWeight);
        values.put("lat_pulldown_sets", latPulldownSets);
        values.put("lat_pulldown_reps", latPulldownReps);
        values.put("deadlift_weight", deadliftWeight);
        values.put("deadlift_sets", deadliftSets);
        values.put("deadlift_reps", deadliftReps);
        values.put("seated_row_weight", seatedRowWeight);
        values.put("seated_row_sets", seatedRowSets);
        values.put("seated_row_reps", seatedRowReps);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_BACK_WORKOUTS, null, values);
    }

    public long saveCardioWorkout(String email, int runningDuration, int jumpRopeDuration,
                                  int cyclingDuration, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("running_duration", runningDuration);
        values.put("jump_rope_duration", jumpRopeDuration);
        values.put("cycling_duration", cyclingDuration);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_CARDIO_WORKOUTS, null, values);
    }

    public long saveChestWorkout(String email, double benchPressWeight, int benchPressSets, int benchPressReps,
                                 double chestFlyWeight, int chestFlySets, int chestFlyReps,
                                 String pushUpWeight, int pushUpSets, int pushUpReps, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("bench_press_weight", benchPressWeight);
        values.put("bench_press_sets", benchPressSets);
        values.put("bench_press_reps", benchPressReps);
        values.put("chest_fly_weight", chestFlyWeight);
        values.put("chest_fly_sets", chestFlySets);
        values.put("chest_fly_reps", chestFlyReps);
        values.put("push_up_weight", pushUpWeight);
        values.put("push_up_sets", pushUpSets);
        values.put("push_up_reps", pushUpReps);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_CHEST_WORKOUTS, null, values);
    }

    public long saveLegWorkout(String email, double squatsWeight, int squatsSets, int squatsReps,
                               double legPressWeight, int legPressSets, int legPressReps,
                               double lungesWeight, int lungesSets, int lungesReps, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("squats_weight", squatsWeight);
        values.put("squats_sets", squatsSets);
        values.put("squats_reps", squatsReps);
        values.put("leg_press_weight", legPressWeight);
        values.put("leg_press_sets", legPressSets);
        values.put("leg_press_reps", legPressReps);
        values.put("lunges_weight", lungesWeight);
        values.put("lunges_sets", lungesSets);
        values.put("lunges_reps", lungesReps);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_LEG_WORKOUTS, null, values);
    }

    public long saveShoulderWorkout(String email, double overheadPressWeight, int overheadPressSets, int overheadPressReps,
                                    double lateralRaiseWeight, int lateralRaiseSets, int lateralRaiseReps,
                                    double frontRaiseWeight, int frontRaiseSets, int frontRaiseReps, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_WORKOUT_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        values.put("overhead_press_weight", overheadPressWeight);
        values.put("overhead_press_sets", overheadPressSets);
        values.put("overhead_press_reps", overheadPressReps);
        values.put("lateral_raise_weight", lateralRaiseWeight);
        values.put("lateral_raise_sets", lateralRaiseSets);
        values.put("lateral_raise_reps", lateralRaiseReps);
        values.put("front_raise_weight", frontRaiseWeight);
        values.put("front_raise_sets", frontRaiseSets);
        values.put("front_raise_reps", frontRaiseReps);
        values.put(COLUMN_WORKOUT_NOTES, notes);

        return db.insert(TABLE_SHOULDER_WORKOUTS, null, values);
    }

    // Methods to get workout history
    public Cursor getAbsWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ABS_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getArmWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ARM_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getBackWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BACK_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getCardioWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_CARDIO_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getChestWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_CHEST_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getLegWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_LEG_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getShoulderWorkouts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_SHOULDER_WORKOUTS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{email},
                null, null, COLUMN_WORKOUT_DATE + " DESC");
    }

    public Cursor getTodayWorkouts(String email, String tableName) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(tableName,
                null,
                COLUMN_USER_EMAIL + " = ? AND " + COLUMN_WORKOUT_DATE + " = ?",
                new String[]{email, today},
                null, null, null);
    }

    public void debugPrintAllCaloriesData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CALORIES, null);

        Log.d("DATABASE_DEBUG", "==== CALORIES TABLE DATA ====");
        if (cursor.moveToFirst()) {
            do {
                String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_EMAIL));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE));
                double taken = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CALORIES_TAKEN));
                double needed = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CALORIES_NEEDED));

                Log.d("DATABASE_DEBUG", String.format(Locale.US,
                        "Email: %s, Date: %s, Taken: %.0f, Needed: %.0f",
                        email, date, taken, needed));
            } while (cursor.moveToNext());
        } else {
            Log.d("DATABASE_DEBUG", "No calories data found!");
        }
        cursor.close();
    }
}