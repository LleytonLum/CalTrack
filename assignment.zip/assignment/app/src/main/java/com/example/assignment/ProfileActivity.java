package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private ImageView profileImage;
    private TextView userName, userEmail, userAge, userGender, userHeight, userWeightGoal;
    private Button editProfileBtn, logoutBtn;
    private ImageButton backButton;
    private DatabaseHelper dbHelper;
    private String currentUserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile); // Replace with your XML layout name

        // Initialize views
        profileImage = findViewById(R.id.profileImage);
        userName = findViewById(R.id.userName);
        userEmail = findViewById(R.id.userEmail);
        userAge = findViewById(R.id.userAge);
        userGender = findViewById(R.id.userGender);
        userHeight = findViewById(R.id.userHeight);
        userWeightGoal = findViewById(R.id.userWeightGoal);
        editProfileBtn = findViewById(R.id.editProfileBtn);
        logoutBtn = findViewById(R.id.logoutBtn);
        backButton = findViewById(R.id.backButton);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get current user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        currentUserEmail = prefs.getString("user_email", null);

        if (currentUserEmail == null) {
            // No user logged in, redirect to login
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Load user data
        loadUserData();

        // Set click listeners
        backButton.setOnClickListener(v -> finish());

        editProfileBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, ProfilesetupActivity.class);
            startActivity(intent);
        });

        logoutBtn.setOnClickListener(v -> logoutUser());
    }

    private void loadUserData() {
        // Get user info from database
        User user = dbHelper.getUser(currentUserEmail);
        if (user != null) {
            userName.setText(user.getName());
            userEmail.setText(user.getEmail());
        }

        // Get profile info from database
        Profile profile = dbHelper.getProfile(currentUserEmail);
        if (profile != null) {
            userAge.setText("Age: " + profile.getAge());
            userGender.setText("Gender: " + profile.getGender());
            userHeight.setText("Height: " + profile.getHeight() + " cm");
            userWeightGoal.setText("Weight Goal: " + profile.getWeightGoal());
        }
    }

    private void logoutUser() {
        // Clear SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        prefs.edit().clear().apply();

        // Redirect to login activity
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning from edit profile
        loadUserData();
    }
}