package com.example.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CaloriesTrackerActivity extends AppCompatActivity {

    private ImageButton backButton;
    private ImageButton addBreakfastBtn;
    private ImageButton addLunchBtn;
    private ImageButton addDinnerBtn;
    private ImageButton addWaterBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calories_tracker);

        // Initialize viewsv
        backButton = findViewById(R.id.backButton);
        addBreakfastBtn = findViewById(R.id.addBreakfastBtn);
        addLunchBtn = findViewById(R.id.addLunchBtn);
        addDinnerBtn = findViewById(R.id.addDinnerBtn);

        // Set click listeners
        backButton.setOnClickListener(v -> finish());

        addBreakfastBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CaloriesTrackerActivity.this, BreakfastActivity.class);
            startActivity(intent);
        });

        addLunchBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CaloriesTrackerActivity.this, LunchActivity.class);
            startActivity(intent);
        });

        addDinnerBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CaloriesTrackerActivity.this, DinnerActivity.class);
            startActivity(intent);
        });
    }
}