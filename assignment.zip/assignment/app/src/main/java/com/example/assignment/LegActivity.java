package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class LegActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText squatsWeight, squatsSets, squatsReps;
    private EditText legPressWeight, legPressSets, legPressReps;
    private EditText lungesWeight, lungesSets, lungesReps;
    private Button saveButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leg);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        drawerLayout = findViewById(R.id.leg_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        squatsWeight = findViewById(R.id.squatsWeight);
        squatsSets = findViewById(R.id.squatsSets);
        squatsReps = findViewById(R.id.squatsReps);
        legPressWeight = findViewById(R.id.legPressWeight);
        legPressSets = findViewById(R.id.legPressSets);
        legPressReps = findViewById(R.id.legPressReps);
        lungesWeight = findViewById(R.id.lungesWeight);
        lungesSets = findViewById(R.id.lungesSets);
        lungesReps = findViewById(R.id.lungesReps);
        saveButton = findViewById(R.id.saveButton);

        // Set up toolbar
        setSupportActionBar(toolbar);
        backButton.setOnClickListener(v -> finish());

        // Set click listeners
        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(LegActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        saveButton.setOnClickListener(v -> saveWorkout());
    }

    private void saveWorkout() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = prefs.getString("user_email", "");

        try {
            double squatsW = Double.parseDouble(squatsWeight.getText().toString());
            int squatsS = Integer.parseInt(squatsSets.getText().toString());
            int squatsR = Integer.parseInt(squatsReps.getText().toString());

            double legPressW = Double.parseDouble(legPressWeight.getText().toString());
            int legPressS = Integer.parseInt(legPressSets.getText().toString());
            int legPressR = Integer.parseInt(legPressReps.getText().toString());

            double lungesW = Double.parseDouble(lungesWeight.getText().toString());
            int lungesS = Integer.parseInt(lungesSets.getText().toString());
            int lungesR = Integer.parseInt(lungesReps.getText().toString());

            long result = dbHelper.saveLegWorkout(email, squatsW, squatsS, squatsR,
                    legPressW, legPressS, legPressR, lungesW, lungesS, lungesR, "");

            if (result != -1) {
                Toast.makeText(this, "Workout saved successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save workout", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please fill all fields with valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}