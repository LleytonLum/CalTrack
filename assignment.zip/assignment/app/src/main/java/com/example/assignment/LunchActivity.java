package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class LunchActivity extends AppCompatActivity {

    // Views
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageButton backButton;
    private ImageView menuButton, profileButton;
    private EditText searchFood;
    private LinearLayout foodContainer;
    private DatabaseHelper dbHelper;
    private String userEmail;

    // Food items data
    private List<FoodItem> foodItems = new ArrayList<>();
    private List<LinearLayout> foodItemViews = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lunch);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userEmail = prefs.getString("user_email", "");

        // Initialize views
        drawerLayout = findViewById(R.id.lunch_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        backButton = findViewById(R.id.backButton);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        searchFood = findViewById(R.id.searchFood);
        foodContainer = findViewById(R.id.food_container);
        backButton = findViewById(R.id.backButton);

        // Initialize food items (replace with your actual data)
        initializeFoodItems();

        // Set up toolbar
        setSupportActionBar(toolbar);

        // Set click listeners
        backButton.setOnClickListener(v -> finish());

        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(navigationView));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(LunchActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                Toast.makeText(this, "Workout clicked", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.nav_report) {
                Toast.makeText(this, "Weekly Summary clicked", Toast.LENGTH_SHORT).show();
            }

            drawerLayout.closeDrawer(navigationView);
            return true;
        });

        // Search functionality
        searchFood.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterFoodItems(s.toString().toLowerCase());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Display all food items initially
        displayFoodItems();
    }

    private void initializeFoodItems() {
        // Add your food items with name, calories per 100g, and image resource
        foodItems.add(new FoodItem("Salmon", 208, R.drawable.food_sample));
        foodItems.add(new FoodItem("Broccoli", 55, R.drawable.food_sample));
        foodItems.add(new FoodItem("Sweet potato", 86, R.drawable.food_sample));
        // Add more food items as needed
    }

    private void displayFoodItems() {
        foodContainer.removeAllViews();
        foodItemViews.clear();

        for (FoodItem foodItem : foodItems) {
            LinearLayout foodItemLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.food_item_layout, null);

            ImageView foodImage = foodItemLayout.findViewById(R.id.food_image);
            TextView foodName = foodItemLayout.findViewById(R.id.food_name);
            EditText quantityInput = foodItemLayout.findViewById(R.id.quantity_input);
            TextView addButton = foodItemLayout.findViewById(R.id.add_button);

            foodImage.setImageResource(foodItem.getImageRes());
            foodName.setText(foodItem.getName());

            // Set default quantity (100g)
            quantityInput.setText("0");

            addButton.setOnClickListener(v -> {
                try {
                    int quantity = Integer.parseInt(quantityInput.getText().toString());
                    double calories = foodItem.getCaloriesPer100g() * quantity / 100.0;

                    // Save to database
                    double currentCalories = dbHelper.getTodayCaloriesData(userEmail)[0];
                    boolean success = dbHelper.saveCaloriesData(userEmail, currentCalories + calories);

                    if (success) {
                        Toast.makeText(LunchActivity.this,
                                String.format("%.0f calories added", calories),
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LunchActivity.this,
                                "Failed to save calories",
                                Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(LunchActivity.this,
                            "Please enter a valid quantity",
                            Toast.LENGTH_SHORT).show();
                }
            });

            foodContainer.addView(foodItemLayout);
            foodItemViews.add(foodItemLayout);
        }
    }

    private void filterFoodItems(String query) {
        if (query.isEmpty()) {
            // Show all items if search is empty
            for (LinearLayout layout : foodItemViews) {
                layout.setVisibility(View.VISIBLE);
            }
            return;
        }

        for (int i = 0; i < foodItems.size(); i++) {
            FoodItem foodItem = foodItems.get(i);
            LinearLayout layout = foodItemViews.get(i);

            if (foodItem.getName().toLowerCase().contains(query)) {
                layout.setVisibility(View.VISIBLE);
            } else {
                layout.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(navigationView)) {
            drawerLayout.closeDrawer(navigationView);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navigationView)) {
            drawerLayout.closeDrawer(navigationView);
        } else {
            super.onBackPressed();
        }
    }

    // FoodItem class to hold food data
    private static class FoodItem {
        private String name;
        private double caloriesPer100g;
        private int imageRes;

        public FoodItem(String name, double caloriesPer100g, int imageRes) {
            this.name = name;
            this.caloriesPer100g = caloriesPer100g;
            this.imageRes = imageRes;
        }

        public String getName() { return name; }
        public double getCaloriesPer100g() { return caloriesPer100g; }
        public int getImageRes() { return imageRes; }
    }
}