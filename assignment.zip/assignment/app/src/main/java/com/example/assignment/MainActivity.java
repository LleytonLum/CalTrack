package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import androidx.appcompat.app.ActionBarDrawerToggle;

public class MainActivity extends AppCompatActivity {

    private TextView remainingCaloriesLabel, remainingCaloriesValue, waterIntakeText, greetingText;
    private Button caloriesTrackerBtn, logWorkoutBtn, weeklySummaryBtn;
    private CircularProgressIndicator progressChart;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ActionBarDrawerToggle toggle;
    private DatabaseHelper dbHelper;
    private ImageView profileIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DatabaseHelper(this);

        // Initialize views
        greetingText = findViewById(R.id.greetingText);
        progressChart = findViewById(R.id.progressChart);
        toolbar = findViewById(R.id.customToolbar);
        profileIcon = findViewById(R.id.profileIcon);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        remainingCaloriesValue = findViewById(R.id.remainingCaloriesValue);
        caloriesTrackerBtn = findViewById(R.id.caloriesTrackerBtn);
        logWorkoutBtn = findViewById(R.id.logWorkoutBtn);
        weeklySummaryBtn = findViewById(R.id.weeklySummaryBtn);

        // Set up UI with user data
        setupUserData();
        setupNavigation();
        setupButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to activity
        setupUserData();
    }

    private void setupUserData() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String userEmail = prefs.getString("user_email", null);

        if (userEmail != null) {
            User user = dbHelper.getUser(userEmail);
            if (user != null) {
                greetingText.setText("Welcome! " + user.getName());

                // Get today's calories data
                double[] caloriesData = dbHelper.getTodayCaloriesData(userEmail);
                double caloriesTaken = caloriesData[0];
                double caloriesNeeded = caloriesData[1];
                double remainingCalories = caloriesNeeded - caloriesTaken;

                // Update UI
                remainingCaloriesValue.setText(String.format("%.0f Kcal", remainingCalories));

                // Calculate progress percentage (0-100)
                int progress = (int) ((caloriesTaken / caloriesNeeded) * 100);
                progressChart.setProgress(progress);

                // Change color based on progress
                if (progress >= 100) {
                    progressChart.setIndicatorColor(getResources().getColor(R.color.red));
                } else if (progress >= 75) {
                    progressChart.setIndicatorColor(getResources().getColor(R.color.orange));
                } else {
                    progressChart.setIndicatorColor(getResources().getColor(R.color.blue));
                }
            }
        }
    }

    private void setupNavigation() {
        profileIcon.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        ImageView hamburgerIcon = findViewById(R.id.hamburgerIcon);
        hamburgerIcon.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                // Already on home
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawers();
            return true;
        });
    }

    private void setupButtons() {
        caloriesTrackerBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CaloriesTrackerActivity.class);
            startActivity(intent);
        });

        logWorkoutBtn.setOnClickListener(v ->
                startActivity(new Intent(this, WorkoutActivity.class)));

        weeklySummaryBtn.setOnClickListener(v ->
                startActivity(new Intent(this, SummaryActivity.class)));}
}