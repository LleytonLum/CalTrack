package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class AbsActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText crunchesSets, crunchesReps, legRaisesSets, legRaisesReps, plankDuration, plankSets;
    private Button saveButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abs);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        drawerLayout = findViewById(R.id.abs_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        crunchesSets = findViewById(R.id.crunchesSets);
        crunchesReps = findViewById(R.id.crunchesReps);
        legRaisesSets = findViewById(R.id.legRaisesSets);
        legRaisesReps = findViewById(R.id.legRaisesReps);
        plankDuration = findViewById(R.id.plankDuration);
        plankSets = findViewById(R.id.plankSets);
        saveButton = findViewById(R.id.saveButton);

        // Set up toolbar
        setSupportActionBar(toolbar);
        backButton.setOnClickListener(v -> finish());
        // Set click listeners
        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(AbsActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        saveButton.setOnClickListener(v -> saveWorkout());
    }

    private void saveWorkout() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = prefs.getString("user_email", "");

        try {
            int crunchesSetsVal = Integer.parseInt(crunchesSets.getText().toString());
            int crunchesRepsVal = Integer.parseInt(crunchesReps.getText().toString());
            int legRaisesSetsVal = Integer.parseInt(legRaisesSets.getText().toString());
            int legRaisesRepsVal = Integer.parseInt(legRaisesReps.getText().toString());
            int plankDurationVal = Integer.parseInt(plankDuration.getText().toString());
            int plankSetsVal = Integer.parseInt(plankSets.getText().toString());

            long result = dbHelper.saveAbsWorkout(email, crunchesSetsVal, crunchesRepsVal,
                    legRaisesSetsVal, legRaisesRepsVal, plankDurationVal, plankSetsVal, "");

            if (result != -1) {
                Toast.makeText(this, "Workout saved successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save workout", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please fill all fields with valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}