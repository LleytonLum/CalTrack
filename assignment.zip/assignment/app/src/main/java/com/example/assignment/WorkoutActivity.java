package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class WorkoutActivity extends AppCompatActivity {

    // Views
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;
    private LinearLayout chestLayout, armLayout, backLayout, legLayout, shoulderLayout, absLayout, cardioLayout;
    private DatabaseHelper dbHelper;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get user email from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userEmail = prefs.getString("user_email", "");

        // Initialize views
        drawerLayout = findViewById(R.id.workout_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        chestLayout = findViewById(R.id.chest_layout);
        armLayout = findViewById(R.id.arm_layout);
        backLayout = findViewById(R.id.back_layout);
        legLayout = findViewById(R.id.leg_layout);
        shoulderLayout = findViewById(R.id.shoulder_layout);
        absLayout = findViewById(R.id.abs_layout);
        cardioLayout = findViewById(R.id.cardio_layout);

        // Set up toolbar
        setSupportActionBar(toolbar);

        // Set click listeners
        backButton.setOnClickListener(v -> finish());

        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(WorkoutActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                // Already on workout page
                drawerLayout.closeDrawer(GravityCompat.START);
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        setupWorkoutCategoryClickListeners();
    }

    private void setupWorkoutCategoryClickListeners() {
        chestLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, ChestActivity.class));
        });

        armLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, ArmActivity.class));
        });

        backLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, BackActivity.class));
        });

        legLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, LegActivity.class));
        });

        shoulderLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, ShoulderActivity.class));
        });

        absLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, AbsActivity.class));
        });

        cardioLayout.setOnClickListener(v -> {
            startActivity(new Intent(WorkoutActivity.this, CardioActivity.class));
        });

        // Add button click listeners
        findViewById(R.id.add_chest_button).setOnClickListener(v -> startActivity(new Intent(this, ChestActivity.class)));
        findViewById(R.id.add_arm_button).setOnClickListener(v -> startActivity(new Intent(this, ArmActivity.class)));
        findViewById(R.id.add_back_button).setOnClickListener(v -> startActivity(new Intent(this, BackActivity.class)));
        findViewById(R.id.add_leg_button).setOnClickListener(v -> startActivity(new Intent(this, LegActivity.class)));
        findViewById(R.id.add_shoulder_button).setOnClickListener(v -> startActivity(new Intent(this, ShoulderActivity.class)));
        findViewById(R.id.add_abs_button).setOnClickListener(v -> startActivity(new Intent(this, AbsActivity.class)));
        findViewById(R.id.add_cardio_button).setOnClickListener(v -> startActivity(new Intent(this, CardioActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}