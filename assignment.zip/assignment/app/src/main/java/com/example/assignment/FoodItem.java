package com.example.assignment;

public class FoodItem {
    private String name;
    private double caloriesPer100g;
    private int imageRes;

    public FoodItem(String name, double caloriesPer100g, int imageRes) {
        this.name = name;
        this.caloriesPer100g = caloriesPer100g;
        this.imageRes = imageRes;
    }

    public String getName() {
        return name;
    }

    public double getCaloriesPer100g() {
        return caloriesPer100g;
    }

    public int getImageRes() {
        return imageRes;
    }
}