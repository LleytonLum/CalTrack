package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfilesetupActivity extends AppCompatActivity {

    private EditText ageInput, weightInput, heightInput;
    private RadioGroup genderGroup, weightGoalGroup;
    private Button startBtn;
    private DatabaseHelper dbHelper;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setup);

        dbHelper = new DatabaseHelper(this);

        // Get current user email
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        userEmail = prefs.getString("user_email", null);
        if (userEmail == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        ageInput = findViewById(R.id.ageInput);
        weightInput = findViewById(R.id.weightInput);
        heightInput = findViewById(R.id.heightInput);
        genderGroup = findViewById(R.id.genderGroup);
        weightGoalGroup = findViewById(R.id.weightGoalGroup);
        startBtn = findViewById(R.id.startBtn);

        // Load existing profile if available
        Profile existingProfile = dbHelper.getProfile(userEmail);
        if (existingProfile != null) {
            ageInput.setText(String.valueOf(existingProfile.getAge()));
            weightInput.setText(String.valueOf(existingProfile.getWeight()));
            heightInput.setText(String.valueOf(existingProfile.getHeight()));

            // Set gender
            if (existingProfile.getGender().equals("Male")) {
                genderGroup.check(R.id.maleRadio);
            } else {
                genderGroup.check(R.id.femaleRadio);
            }

            // Set weight goal
            if (existingProfile.getWeightGoal() != null) {
                switch (existingProfile.getWeightGoal()) {
                    case "Lose Weight":
                        weightGoalGroup.check(R.id.loseWeightRadio);
                        break;
                    case "Maintain Weight":
                        weightGoalGroup.check(R.id.maintainWeightRadio);
                        break;
                    case "Gain Weight":
                        weightGoalGroup.check(R.id.gainWeightRadio);
                        break;
                }
            }
        }

        startBtn.setOnClickListener(v -> {
            if (validateInputs()) {
                saveProfileData();
                Toast.makeText(this, "Profile saved successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ProfilesetupActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private boolean validateInputs() {
        // Validate age
        String ageStr = ageInput.getText().toString().trim();
        if (ageStr.isEmpty()) {
            ageInput.setError("Please enter your age");
            return false;
        }
        try {
            int age = Integer.parseInt(ageStr);
            if (age < 1 || age > 120) {
                ageInput.setError("Please enter a valid age (1-120)");
                return false;
            }
        } catch (NumberFormatException e) {
            ageInput.setError("Please enter a valid number");
            return false;
        }

        // Validate weight
        String weightStr = weightInput.getText().toString().trim();
        if (weightStr.isEmpty()) {
            weightInput.setError("Please enter your weight");
            return false;
        }
        try {
            float weight = Float.parseFloat(weightStr);
            if (weight < 2 || weight > 500) {
                weightInput.setError("Please enter a valid weight (2-500 kg)");
                return false;
            }
        } catch (NumberFormatException e) {
            weightInput.setError("Please enter a valid number");
            return false;
        }

        // Validate height
        String heightStr = heightInput.getText().toString().trim();
        if (heightStr.isEmpty()) {
            heightInput.setError("Please enter your height");
            return false;
        }
        try {
            float height = Float.parseFloat(heightStr);
            if (height < 50 || height > 250) {
                heightInput.setError("Please enter a valid height (50-250 cm)");
                return false;
            }
        } catch (NumberFormatException e) {
            heightInput.setError("Please enter a valid number");
            return false;
        }

        // Validate gender selection
        if (genderGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select your gender", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate weight goal selection
        if (weightGoalGroup.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select your weight goal", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void saveProfileData() {
        int age = Integer.parseInt(ageInput.getText().toString().trim());
        float weight = Float.parseFloat(weightInput.getText().toString().trim());
        float height = Float.parseFloat(heightInput.getText().toString().trim());

        // Get selected gender
        int selectedGenderId = genderGroup.getCheckedRadioButtonId();
        RadioButton selectedGender = findViewById(selectedGenderId);
        String gender = selectedGender.getText().toString();

        // Get selected weight goal
        int selectedGoalId = weightGoalGroup.getCheckedRadioButtonId();
        RadioButton selectedGoal = findViewById(selectedGoalId);
        String weightGoal = selectedGoal.getText().toString();

        // Save to database
        boolean success = dbHelper.saveProfile(userEmail, age, weight, height, gender, weightGoal);

        if (!success) {
            Toast.makeText(this, "Failed to save profile", Toast.LENGTH_SHORT).show();
        }
    }
}