package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class BackActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText latPulldownWeight, latPulldownSets, latPulldownReps;
    private EditText deadliftWeight, deadliftSets, deadliftReps;
    private EditText seatedRowWeight, seatedRowSets, seatedRowReps;
    private Button saveButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        drawerLayout = findViewById(R.id.back_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        latPulldownWeight = findViewById(R.id.latPulldownWeight);
        latPulldownSets = findViewById(R.id.latPulldownSets);
        latPulldownReps = findViewById(R.id.latPulldownReps);
        deadliftWeight = findViewById(R.id.deadliftWeight);
        deadliftSets = findViewById(R.id.deadliftSets);
        deadliftReps = findViewById(R.id.deadliftReps);
        seatedRowWeight = findViewById(R.id.seatedRowWeight);
        seatedRowSets = findViewById(R.id.seatedRowSets);
        seatedRowReps = findViewById(R.id.seatedRowReps);
        saveButton = findViewById(R.id.saveButton);

        // Set up toolbar
        setSupportActionBar(toolbar);
        backButton.setOnClickListener(v -> finish());
        // Set click listeners
        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(BackActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        saveButton.setOnClickListener(v -> saveWorkout());
    }

    private void saveWorkout() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = prefs.getString("user_email", "");

        try {
            double latWeight = Double.parseDouble(latPulldownWeight.getText().toString());
            int latSets = Integer.parseInt(latPulldownSets.getText().toString());
            int latReps = Integer.parseInt(latPulldownReps.getText().toString());

            double deadliftWeightVal = Double.parseDouble(deadliftWeight.getText().toString());
            int deadliftSetsVal = Integer.parseInt(deadliftSets.getText().toString());
            int deadliftRepsVal = Integer.parseInt(deadliftReps.getText().toString());

            double seatedRowWeightVal = Double.parseDouble(seatedRowWeight.getText().toString());
            int seatedRowSetsVal = Integer.parseInt(seatedRowSets.getText().toString());
            int seatedRowRepsVal = Integer.parseInt(seatedRowReps.getText().toString());

            long result = dbHelper.saveBackWorkout(email, latWeight, latSets, latReps,
                    deadliftWeightVal, deadliftSetsVal, deadliftRepsVal,
                    seatedRowWeightVal, seatedRowSetsVal, seatedRowRepsVal, "");

            if (result != -1) {
                Toast.makeText(this, "Workout saved successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save workout", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please fill all fields with valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}