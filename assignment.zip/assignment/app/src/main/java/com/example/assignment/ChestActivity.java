package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class ChestActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText benchPressWeight, benchPressSets, benchPressReps;
    private EditText chestFlyWeight, chestFlySets, chestFlyReps;
    private EditText pushUpWeight, pushUpSets, pushUpReps;
    private Button saveButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chest);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        drawerLayout = findViewById(R.id.chest_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        benchPressWeight = findViewById(R.id.benchPressWeight);
        benchPressSets = findViewById(R.id.benchPressSets);
        benchPressReps = findViewById(R.id.benchPressReps);
        chestFlyWeight = findViewById(R.id.chestFlyWeight);
        chestFlySets = findViewById(R.id.chestFlySets);
        chestFlyReps = findViewById(R.id.chestFlyReps);
        pushUpWeight = findViewById(R.id.pushUpWeight);
        pushUpSets = findViewById(R.id.pushUpSets);
        pushUpReps = findViewById(R.id.pushUpReps);
        saveButton = findViewById(R.id.saveButton);

        // Set up toolbar
        setSupportActionBar(toolbar);
        backButton.setOnClickListener(v -> finish());

        // Set click listeners
        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(ChestActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        saveButton.setOnClickListener(v -> saveWorkout());
    }

    private void saveWorkout() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = prefs.getString("user_email", "");

        try {
            double benchWeight = Double.parseDouble(benchPressWeight.getText().toString());
            int benchSets = Integer.parseInt(benchPressSets.getText().toString());
            int benchReps = Integer.parseInt(benchPressReps.getText().toString());

            double flyWeight = Double.parseDouble(chestFlyWeight.getText().toString());
            int flySets = Integer.parseInt(chestFlySets.getText().toString());
            int flyReps = Integer.parseInt(chestFlyReps.getText().toString());

            String pushUpW = pushUpWeight.getText().toString();
            int pushUpS = Integer.parseInt(pushUpSets.getText().toString());
            int pushUpR = Integer.parseInt(pushUpReps.getText().toString());

            long result = dbHelper.saveChestWorkout(email, benchWeight, benchSets, benchReps,
                    flyWeight, flySets, flyReps, pushUpW, pushUpS, pushUpR, "");

            if (result != -1) {
                Toast.makeText(this, "Workout saved successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save workout", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please fill all required fields with valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}