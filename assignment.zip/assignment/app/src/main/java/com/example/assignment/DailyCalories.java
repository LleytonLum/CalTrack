package com.example.assignment;

public class DailyCalories {
}
