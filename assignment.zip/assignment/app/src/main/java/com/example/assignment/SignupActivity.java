package com.example.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {
    EditText signupEmailEditText, signupPasswordEditText, signupNameEditText;
    Button signupButton;
    TextView goToLoginText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        dbHelper = new DatabaseHelper(this);
        signupNameEditText = findViewById(R.id.signupNameEditText);
        signupEmailEditText = findViewById(R.id.signupEmailEditText);
        signupPasswordEditText = findViewById(R.id.signupPasswordEditText);
        signupButton = findViewById(R.id.signupButton);
        goToLoginText = findViewById(R.id.goToLoginText);

        signupButton.setOnClickListener(v -> {
            String name = signupNameEditText.getText().toString();
            String email = signupEmailEditText.getText().toString();
            String password = signupPasswordEditText.getText().toString();

            if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                long result = dbHelper.addUser(name, email, password);
                if (result != -1) {
                    Toast.makeText(this, "Signup successful!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, LoginActivity.class));
                } else {
                    Toast.makeText(this, "Signup failed (email may exist)", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            }
        });
        goToLoginText.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
        });
    }
}
