package com.example.assignment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class CardioActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText runningDuration, jumpRopeDuration, cyclingDuration;
    private Button saveButton;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ImageView menuButton, profileButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardio);

        dbHelper = new DatabaseHelper(this);

        // Initialize views
        drawerLayout = findViewById(R.id.cardio_drawer);
        navigationView = findViewById(R.id.navigation_view);
        toolbar = findViewById(R.id.toolbar);
        menuButton = findViewById(R.id.menuButton);
        profileButton = findViewById(R.id.profileButton);
        backButton = findViewById(R.id.backButton);
        runningDuration = findViewById(R.id.runningDuration);
        jumpRopeDuration = findViewById(R.id.jumpRopeDuration);
        cyclingDuration = findViewById(R.id.cyclingDuration);
        saveButton = findViewById(R.id.saveButton);

        // Set up toolbar
        setSupportActionBar(toolbar);
        backButton.setOnClickListener(v -> finish());
        // Set click listeners
        menuButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(CardioActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // Set up navigation drawer
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
            } else if (id == R.id.nav_calories) {
                startActivity(new Intent(this, CaloriesTrackerActivity.class));
            } else if (id == R.id.nav_workout) {
                startActivity(new Intent(this, WorkoutActivity.class));
            } else if (id == R.id.nav_report) {
                startActivity(new Intent(this, SummaryActivity.class));
            }
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

        saveButton.setOnClickListener(v -> saveWorkout());
    }

    private void saveWorkout() {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = prefs.getString("user_email", "");

        try {
            int runningDur = Integer.parseInt(runningDuration.getText().toString());
            int jumpRopeDur = Integer.parseInt(jumpRopeDuration.getText().toString());
            int cyclingDur = Integer.parseInt(cyclingDuration.getText().toString());

            long result = dbHelper.saveCardioWorkout(email, runningDur, jumpRopeDur, cyclingDur, "");

            if (result != -1) {
                Toast.makeText(this, "Workout saved successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save workout", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please fill all fields with valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}