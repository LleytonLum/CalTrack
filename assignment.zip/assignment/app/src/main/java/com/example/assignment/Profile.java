package com.example.assignment;

public class Profile {
    private int age;
    private float weight;
    private float height;
    private String gender;
    private String weightGoal;

    public Profile(int age, float weight, float height, String gender, String weightGoal) {
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.gender = gender;
        this.weightGoal = weightGoal;
    }

    // Add getter and setter for weightGoal
    public String getWeightGoal() { return weightGoal; }
    public void setWeightGoal(String weightGoal) { this.weightGoal = weightGoal; }

    // Getters and setters
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public float getWeight() { return weight; }
    public void setWeight(float weight) { this.weight = weight; }
    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
}